 
This UI Kit was designed by Dennis Terrey. Big thanks for making this available:

http://www.killercreations.co.uk/volcanic-ui-kit.php