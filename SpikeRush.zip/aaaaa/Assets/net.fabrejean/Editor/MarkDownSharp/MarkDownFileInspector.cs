﻿// Obsolete file, you can safely delete, refer to ObjectInspector.cs
// ISSUE: I named the file different than the class, and Unity loose the reference and throw the following error :
// Instance of ObjectInspector couldn't be created because there is no script with that name.